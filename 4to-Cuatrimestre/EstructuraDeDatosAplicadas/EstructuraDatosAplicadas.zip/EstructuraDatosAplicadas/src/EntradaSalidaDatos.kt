fun main(){
    print("dame el valor de a: ")
    var a = readln().toInt()
    print("dame el valor de b: ")
    var b = readln().toInt()
    println("la suma de " +a+ " + " +b+ " = " +(a+b))
    println("la suma de $a + $b = ${a+b}")
    println("la resta de $a - $b = ${a-b}")
    println("la multiplicacion de $a * $b = ${a*b}")
    println("la division de $a / $b = ${a/b}")
    println("el residuo de $a % $b = ${a%b}")
}